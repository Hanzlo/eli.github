<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
	<title>Best Olive Oil</title>

		<meta charset="utf-8" />
		<meta name="Description" content="Define a description of your web page" />
		<meta name="Keywords" content="Add, only, important, words, here"/>
<?php include("scripts.php");?>
</head>

<body>
<?php include("nav-caro.php");?>

<main>
<div class="container">
	
	<div class="row">
	  <div class="col-md-12 about-section-p">
	<div align="center" class="about-title">
                              <h2 class="text-uppercase solid-weight">about us</h2>
                              <span class="text-uppercase our-story">our company name</span>
                              <div class="divider"></div>
                           </div>
<p><strong>Company Name </strong>is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
<p>
There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, </p>

<p>
All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>



</div>
	
		<div class="senz-analize-section">
<p><strong>RESULTS OF ANALYSIS</strong></p>
		


<div >
<ul>
<li><a href="#" title="RESULTS OF ANALYSIS" target="new">RESULTS OF ANALYSIS.PDF</a>
</li>
<li><a href="#" title="MRESULTS OF ANALYSIS" target="new">RESULTS OF ANALYSIS.PDF</a></li>

</ul>
</div>
</div>
		
	</div>
	</div>
	
	<div class="container-fluid " style="padding: 0px">
		
		<div class="section-image">
			<h1>Your satisfaction is our priority</h1>
			
		</div>
	</div>
	
	
	<div class="container">
	
	<div class="row">
	  
	
	
		<div class="col-md-12 about-section-p">
			
			
	<div align="center" class="about-title">
                              <h2 class="text-uppercase solid-weight">Name of your olive oil</h2>
                              <span class="text-uppercase our-story">EXTRA VIRGIN OLIVE OIL</span>
                              <div class="divider"></div>
                           </div>

<p>Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. <strong>EXTRA VIRGIN OLIVE OIL.</strong></p> 

<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33</p>

  <p>If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary</p>
	
		
</div>

	</div>
	</div>
</main>

<div class="container">
		<div align="center" class="about-title">
		  <h2 class="text-uppercase solid-weight">GALERY</h2>
		  <span class="text-uppercase our-story">We have a total of 110 olive trees planted</span>
		  <div class="divider"></div>
  </div>
  <section>
  
  
<!--  GALERY IMAGES-->
  
  <div class="container gal-container">
   <div class="row">
    <div class="col-md-4 gal-item">
      <div class="box ">
        <a  href="#"  data-toggle="modal" data-target="#1">
          <img  src="images/10425427_909065595789639_8384984217477919193_n.jpg">
        </a>
        <div class="modal fade " id="1" tabindex="-1" role="dialog">
          <div class="modal-dialog " role="document">
            <div class="modal-content">
                <button type="button" class="close " data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
              <div class="modal-body">
                <img src="images/10425427_909065595789639_8384984217477919193_n.jpg">
              </div>
    
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-4 gal-item">
      <div class="box">
        <a href="#" data-toggle="modal" data-target="#2">
          <img src="images/20161016_165444_resized.jpg">
        </a>
        <div class="modal fade" id="2" tabindex="-1" role="dialog">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
              <div class="modal-body">
                <img src="images/20161016_165444_resized.jpg">
              </div>
        
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 co-xs-12 gal-item">
      <div class="box">
        <a href="#" data-toggle="modal" data-target="#3">
          <img src="images/20161016_170215_resized.jpg">
        </a>
        <div class="modal fade" id="3" tabindex="-1" role="dialog">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
              <div class="modal-body">
               <img src="images/20161016_170215_resized.jpg">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-4 col-sm-6 co-xs-12 gal-item">
      <div class="box">
        <a href="#" data-toggle="modal" data-target="#4">
          <img src="images/20161016_170914_resized.jpg">
        </a>
        <div class="modal fade" id="4" tabindex="-1" role="dialog">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
              <div class="modal-body">
                 <img src="images/20161016_170914_resized.jpg">
              </div>
        
            </div>
          </div>
        </div>
      </div>
    </div>

<div class="col-md-8 col-sm-12 co-xs-12 gal-item">
  <div class="box">
        <a href="#" data-toggle="modal" data-target="#10">
          <img src="images/20161030_193506.jpg">
        </a>
        <div class="modal fade" id="10" tabindex="-1" role="dialog">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
              <div class="modal-body">
               <img src="images/20161030_193506.jpg">
              </div>
        
            </div>
          </div>
        </div>
      </div>
  </div>
</div>
  </div>
  <!--  GALERY IMAGES END-->
</section>
	
</div>

<?php include("footer.php"); ?>
</body>
</html>
