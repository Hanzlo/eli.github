<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
	<title>Best Olive Oil</title>

		<meta charset="utf-8" />
		<meta name="Description" content="Define a description of your web page" />
		<meta name="Keywords" content="Add, only, important, words, here"/>
<?php include("scripts.php");?>
</head>

<body>

<?php include("nav-caro.php");?>
<div>
	<div style="margin-top: 60px" align="center" class="about-title">
                              <h2 class="text-uppercase solid-weight">Location</h2>
                              <span class="text-uppercase our-story">Find us with Google Maps</span>
                              <div class="divider"></div>
            <div class="google-mapa-wrap">            
	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d310843.46418524033!2d13.144551916009208!3d52.506931247836306!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a84e373f035901%3A0x42120465b5e3b70!2sBerlin%2C+Njema%C4%8Dka!5e0!3m2!1shr!2shr!4v1517567984733" width="100%" height="550" frameborder="0" style="border:0" allowfullscreen></iframe></div>  
</div>

<!--CONTACT US-->
<section class="pad-80" id="contact-section">
			<div class="container">
				<div class="row">
				    <div class="col-lg-6 ">
				        <div class="contact-form margin-bot-kont">
                            <h4>Contact us</h4>
				            <form action="contact-php.php">
				                <input type="text" placeholder="Your Name">
				                <input type="email" placeholder="Email Addres">
				                <textarea placeholder="Message"></textarea>
				                <button class="maslina-btn">Send Message</button>
				            </form>
				        </div>
				    </div>
				    <div class="col-lg-6">
				        <div class="contact-form">
                            <h4>Visit Us</h4>
				            <div class="contact-area">
				            <strong>Addres:</strong>
<p>Street Name 2<br> 23000 Boston</p>
							<strong>Contact:</strong>
								<p>
			                Email: your.email@gmail.com
				                <br>  
				                Phone: 098445005056
     
			                </p>
				                
				            </div>
				        </div>
				    </div>
				</div>
			</div>
		</section>
<!--CONTACT US END-->


<?php include("footer.php"); ?>
</body>

</html>
