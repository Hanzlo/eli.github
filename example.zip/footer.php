
<!--Footer-->
<footer>
	<div class="footer-bottom">
                     <div class="container">
                        <div class="row">
                           <div align="center"  class="col-sm-4">© 2018 Your Company</div>
                           <div align="center"  class="col-sm-4">Hosted by You<span style="color: #FE5A22"> Developer</span></div>
                           <div align="center"  class="col-sm-4">
                              <ul class="list-inline">
								  <li class="list-inline-item"><a href="#"><i class="fa fa-facebook"></i></a></li>
  <li class="list-inline-item"><a href="#"><i class="fa fa-twitter"></i></a></li>
  <li class="list-inline-item"><a href="#"><i class="fa fa-instagram"></i></a></li><li class="list-inline-item"><a href="#"><i class="fa fa-google"></i></a></li>
</ul>
                           </div>
                        </div>
                     </div>
                  </div>
	
</footer>
<!--FOOTER END-->