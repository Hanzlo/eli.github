<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
	<title>Best Olive Oil</title>

		<meta charset="utf-8" />
		<meta name="Description" content="Define a description of your web page" />
		<meta name="Keywords" content="Add, only, important, words, here"/>
<?php include("scripts.php");?>

</head>

<body>

<?php include("nav-caro.php");?>


	
<div class="about-home">
	<div class="about-title ">
                              <h2 class="text-uppercase solid-weight">Something about us</h2>
                              <span class="text-uppercase our-story">Our Story</span>
                              <div class="divider"></div>
                           </div>

	
<div class="container">
				<div class="row">
					<div class="col-lg-6">
                        <div class="about-img1">
                            <img class="img-fluid about-short-wrapper-img" src="images/10425427_909065595789639_8384984217477919193_n.jpg" alt="about">
                        </div>
					</div>
					<div class="col-lg-6">
                        <div class="about-short-wrapper">
                          
                     <p>
<strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>	

<p>
It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>


<strong>Lorem Ipsum</strong>
<br>
<p>is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                            <a href="contact-php.php" class="">Contact Us</a>
                      </div>
					</div>
				</div>
			</div>
</div>
<div class="div-2"> 
	<div class="container">

  <div class="row">
	  <div class="col-md-4">
	  	<div class="div-2-titles about-title">
	  		<h2>WHY</h2>
	  	<span class="text-uppercase our-story our-story-smaller">use olive oil</span>
	  	<div class="divider"></div>
	  	<p  class="p-frame">Olive oil is one of the healthiest foods known to man since the world and the ages. Use it as a spice, for cooking, or for cosmetic purposes.</p>


	  	</div>
	  </div>
	  
	  
	  <div class="col-md-4">
	  	<div class="div-2-titles about-title">
	  	<h2>HOW</h2>
	  	<span class="text-uppercase our-story our-story-smaller">do we make our olive oil?</span>
	  	<div class="divider"></div>
	  	<p  class="p-frame">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
	  	
	 
	  	</div>
	  </div>
	  
	  
	  <div class="col-md-4">
	  	<div class="div-2-titles about-title">
	  	  <h2>WHERE</h2>
	  	  <span class="text-uppercase our-story our-story-smaller">are our olive groves</span>
	  	  <div class="divider"></div>
	  	<p class="p-frame">All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. </p>
	  	
	
	  	</div>
	  </div>
	  

	 
	 	
	 </div>
		
	</div>
</div>

<div class="div-1"> 
	<div class="container">
		<div class="about-title pad-bot-40">
                              <h2 class="text-uppercase solid-weight">Offer and prices</h2>
                              <span class="text-uppercase our-story">EXTRA VIRGIN OLIVE OIL</span>
                              <div class="divider"></div>
                           </div>
  <div class="row">
	  <div class="col-md-4">
	  	<div class="div-1-titles about-title">
	  	  <h2>1 Liter</h2>
	  	  <span class="text-uppercase our-story our-story-smaller">Some text</span>
	    	<br>
	  	<p>
	  	<img width="100" class="img-fluid" src="images/isolated-2437752_1280.png" alt="OLIVE OIL"></p>
	  	<p  class="p-frame">Lorem Ipsum is simply dummy text of the printing and typesetting industry.
	  	<br><a href="contact.php">Contact Us</a></p>
	  	
	 
	  	</div>
	  </div>
	  
	  
	  <div class="col-md-4">
	  	<div class="div-1-titles about-title">
	  	  <h2>0,75 Liters</h2>
	  	  <span class="text-uppercase our-story our-story-smaller">Some text</span>
	    	<br>
	  	<p>
	  	<img width="100" class="img-fluid" src="images/isolated-2437752_1280.png" alt="OLIVE OIL"></p>
	  	<p  class="p-frame">Lorem Ipsum is simply dummy text of the printing and typesetting industry.
	  	<br><a href="contact.php">Contact Us</a></p>
	  	
	 
	  	</div>
	  </div>
	  
	  
	  <div class="col-md-4">
	  	<div class="div-1-titles about-title">
	  	  <h2>0,5 Liters</h2>
	  	  <span class="text-uppercase our-story our-story-smaller">Some text</span>
	  	  	<br>
	  	<p>
	  	<img width="100" class="img-fluid" src="images/isolated-2437752_1280.png" alt="OLIVE OIL"></p>
	  	<p class="p-frame">All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary.<br>
	  	<a href="contact.php">Contact Us</a> </p>
	  	
	
	  	</div>
	  </div>
	  

	 
	 	
	 </div>
		
	</div>
</div>



<!--CONTACT US-->
<section class="pad-80" id="contact-section">
			<div class="container">
				<div class="row">
				    <div class="col-lg-6 ">
				        <div class="contact-form margin-bot-kont">
                            <h4>Contact us</h4>
				            <form action="contact-php.php">
				                <input type="text" placeholder="Your Name">
				                <input type="email" placeholder="Email Addres">
				                <textarea placeholder="Message"></textarea>
				                <button class="maslina-btn">Send Message</button>
				            </form>
				        </div>
				    </div>
				    <div class="col-lg-6">
				        <div class="contact-form">
                            <h4>Visit Us</h4>
				            <div class="contact-area">
				            <strong>Addres:</strong>
<p>Street Name 2<br> 23000 Boston</p>
							<strong>Contact:</strong>
								<p>
			                Email: your.email@gmail.com
				                <br>  
				                Phone: 098445005056
     
			                </p>
				                
				            </div>
				        </div>
				    </div>
				</div>
			</div>
		</section>
<!--CONTACT US END-->

<?php include("footer.php"); ?>
</body>

</html>
